#ifndef FIO_COMPILER_GCC4_H
#define FIO_COMPILER_GCC4_H

#ifndef __must_check
#define __must_check		__attribute__((warn_unused_result))
#endif

#endif
