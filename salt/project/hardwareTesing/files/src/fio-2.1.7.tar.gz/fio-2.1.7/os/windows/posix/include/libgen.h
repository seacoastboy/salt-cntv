#ifndef LIBGEN_H
#define LIBGEN_H

char *basename(char *path);

#endif /* LIBGEN_H */
